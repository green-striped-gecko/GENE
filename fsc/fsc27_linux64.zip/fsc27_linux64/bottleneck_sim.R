#estimate parameters from SFS
#simulate a population

obs.p <- fscWrite(
  demes = fscSettingsDemes(fscDeme(deme.size = 7300,sample.size =  20)),
  events = fscSettingsEvents(
    fscEvent(event.time = 9800, source = 0, sink = 0, prop.migrants = 0, new.size = 3.5),
    fscEvent(event.time = 9900, source = 0, sink = 0, prop.migrants = 0, new.size = 1)
  ),
  genetics = fscSettingsGenetics(fscBlock_snp(10, 2.5e-6), num.chrom = 200000),
  label = "known.1PopBot20Mb"
)
obs.p <- fscRun(obs.p, dna.to.snp = TRUE, no.arl.output = TRUE, num.cores = 3, sfs.type = "maf" )
obs.sfs <- fscReadSFS(obs.p)
barplot(obs.sfs$sfs$marginal[[1]][2:40])


demes <- fscSettingsDemes(fscDeme(deme.size = "NCUR", sample.size = 20))
events <- fscSettingsEvents(
  fscEvent(event.time = "TBOT", 0, 0, 0, new.size = "RESBOT"),
  fscEvent(event.time = "TENDBOT", 0, 0, 0,new.size =  "RESENDBOT")
)

est <- fscSettingsEst(
  fscEstParam("NCUR", is.int = TRUE, distr = "unif", min = 10, max = 100000),
  # default for is.int = TRUE and distr = "unif" 
  fscEstParam("NANC", min = 10, max = 100000),
  fscEstParam("NBOT", min = 10, max = 100000),
  fscEstParam("TBOT", min = 10, max = 10000),
  # these are "complex parameters" (only name and value are given)
  fscEstParam("RESBOT", is.int = FALSE, value = "NBOT/NCUR", output = FALSE),
  fscEstParam("RESENDBOT", is.int = FALSE, value = "NANC/NBOT", output = FALSE),
  fscEstParam("TENDBOT", value = "TBOT+100", output = FALSE),
  obs.sfs = obs.sfs$sfs$marginal[[1]]
)
est

est.p <- fscWrite(
  demes = demes,
  events = events,
  genetics = fscSettingsGenetics(fscBlock_freq(2.5e-6)),
  est = est,
  label = "est.1PopBot20Mb"
)
system.time(est.p <- fscRun(est.p, num.sims = 500000, num.cores = 20))


param.est <- fscReadParamEst(est.p )

#readLines(file.path(est.p$folders, est.p$))


#str(param.est)

