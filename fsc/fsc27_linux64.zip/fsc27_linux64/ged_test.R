#Simulate some data with a bottleneck 50 generations ago...
#coalescent -> SFS -> estimate parameters
library(strataG)
library(dartR)
setwd("~/fsc/fsc27_linux64/")
demes <- fscSettingsDemes(fscDeme(deme.size = 50, sample.size = 50))
genetics <- fscSettingsGenetics(fscBlock_snp(sequence.length = 10, mut.rate = 1e-5), num.chrom = 5000)

events <- fscSettingsEvents(
  fscEvent(
    event.time = 50, 
    source = 0, 
    sink = 0, 
    prop.migrants = 0, 
    new.size = 0.5,
    new.growth = 0,
    migr.mat = 0
  ),
  fscEvent(
    event.time = 100, 
    source = 0, 
    sink = 0, 
    prop.migrants = 0, 
    new.size = 10,
    new.growth = 0,
    migr.mat = 0
  ))

p <- fscWrite(demes = demes, genetics = genetics, events = events, label = "habitat_destroy")


obs.p <- fscRun(p, dna.to.snp = TRUE, no.arl.output = FALSE, num.cores = 3, sfs.type = "maf" , all.sites = F)


#convert to genlight
snp.df <- fscReadArp(obs.p)
gl <- gtypes2genlight(df2gtypes(snp.df, ploidy = 2))
gl.smearplot(gl)

#not filtered for multiple snp on the 10 base sequence!

#folded sfs
sfs <- table((0.5-abs(0.5-gl.alf(gl)[,1]))*nInd(gl)*2)
#we do not need/know/use the first frequency [number of unaltered loci]
sfs_fsc <- as.numeric(sfs[-1])
barplot(sfs_fsc)[2:10]
#for a comparison I look at the fsc SFS

#sfs from fastsimcoal simulation
obs.sfs <- fscReadSFS(obs.p)
barplot((obs.sfs$sfs$marginal[[1]])[2:10])



#test if parameters can be reconstructed....(not run long enought so fairly poor)
demes <- fscSettingsDemes(fscDeme(deme.size = "NCUR", sample.size = 50))
events <- fscSettingsEvents(
  fscEvent(event.time = "TBOTSTART", 0, 0, 0, new.size = "NBOT"),
  fscEvent(event.time = "TBOTEND", 0, 0, 0, new.size =10)
)

est <- fscSettingsEst(
  fscEstParam("NCUR", is.int = TRUE, distr = "unif", min = 10, max = 1000),
  # default for is.int = TRUE and distr = "unif" 
#  fscEstParam("NANC", min = 10, max = 1000),
  fscEstParam("NBOT", min = 5, max = 200),
  fscEstParam("TBOTSTART", min = 1, max = 200),
#  fscEstParam("RESEND", is.int = FALSE, value = "NBOT/NCUR", output = FALSE),
#  fscEstParam("RESBEG", is.int = FALSE, value = "NANC/NBOT", output = FALSE),
  fscEstParam("TBOTEND", value = "TBOTSTART+50", output = FALSE),
  obs.sfs = sfs_fsc
)
#est

est.p <- fscWrite(
  demes = demes,
  events = events,
  genetics = fscSettingsGenetics(fscBlock_freq(1e-5)),
  est = est,
  label = "est.habdestroy"
)
system.time(est.p <- fscRun(est.p, num.sims = 200000, num.cores = 10))

#not sure what this function does as it does not read all outputs....
param.est <- fscReadParamEst(est.p )

#check bestlhoods
(readLines(file.path( est.p$folder, "est.habdestroy/est.habdestroy.bestlhoods")))




