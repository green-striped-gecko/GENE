###
# 1. run fastsimcoal to generate initial data
# 2. get output into R
# 3. create a sfs in R


#simple example (10 individuals, 1000 chromosomes)
library(strataG)
library(dartR)
setwd("~/fsc/fsc27_linux64/")
demes <- fscSettingsDemes(fscDeme(deme.size = 1000, sample.size = 10))
genetics <- fscSettingsGenetics(fscBlock_snp(sequence.length = 10, mut.rate = 1e-7), num.chrom = 10000)
p <- fscWrite(demes = demes, genetics = genetics, label = "ex2.snps.1k2")
p <- fscRun(p, all.sites = F, dna.to.snp =FALSE)

snp.df <- fscReadArp(p)


#convert to genlight  

gl <- gtypes2genlight(df2gtypes(snp.df, ploidy = 2))

#filter only first snp on sequence
ll <- nchar(gl@loc.names)
nn <- substr(locNames(gl),ll-2,ll)
index <- (nn=="SNP" | nn=="_L1")

glf <- gl[, index]
table(as.matrix(glf))

glf <- gl.compliance.check(glf)
#hack for gf2sfs function (@Luis we need to set verbose to NULL)
verbose=0
#
gl.smearplot(glf)

#folded sfs
sfs <- table((0.5-abs(0.5-gl.alf(glf)[,1]))*nInd(glf)*2)

barplot(sfs)








